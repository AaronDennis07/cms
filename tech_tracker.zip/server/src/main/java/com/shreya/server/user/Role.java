package com.shreya.server.user;

public enum Role {
    ADMIN,
    USER
}
