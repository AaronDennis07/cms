import React from 'react'
import ListApplicationsAdmin from '../components/ListApplicationsAdmin'

const ListApplicationsAdminPage = () => {
  return (
    <ListApplicationsAdmin/>
  )
}

export default ListApplicationsAdminPage